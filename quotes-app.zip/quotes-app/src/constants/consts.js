export const imageBase = "https://theysaidso.com/";
export const apiBase = "https://quotes.rest/";
